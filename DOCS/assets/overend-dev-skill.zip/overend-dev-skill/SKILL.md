---
name: overend-dev
description: Specialized skill for OVEREND macOS academic literature management app development. Use for daily development tasks (bug fixes, new features), code review and optimization, direct Xcode project editing, and automatic documentation updates (PROJECT_STATUS.md and development diary). Handles Swift/SwiftUI code, follows project naming conventions, validates theme system usage, and ensures Traditional Chinese localization.
---

# OVEREND Development Assistant

## Overview

專為 OVEREND macOS 學術文獻管理應用開發設計的 Agent Skill。協助執行日常開發任務、程式碼編輯，並自動維護專案文件與開發日記。

OVEREND 是針對台灣學術社群設計的「EndNote 殺手」，提供文獻管理與寫作整合的原生 macOS 應用。

## When to Use This Skill

使用此 skill 的情境：
- 修復 OVEREND 專案的 bug
- 新增功能或視圖元件
- 程式碼審查與優化建議
- 檢查命名規範、主題系統、中文化
- 更新專案進度文件
- 生成開發日記記錄

**不使用此 skill 的情境**：
- 一般性 Swift 或 SwiftUI 問題（與 OVEREND 專案無關）
- 非開發類問題（如市場分析、商業策略）

## Project Context

### 基本資訊
- **專案路徑**: `/Users/lawliet/OVEREND`
- **專案檔**: `OVEREND.xcodeproj`
- **主要程式碼**: `OVEREND/`
- **框架**: SwiftUI + Core Data + PDFKit
- **目標平台**: macOS 13.0+
- **主色調**: `#00D97E`

### 專案結構
```
OVEREND/
├── OVEREND.xcodeproj
├── OVEREND/
│   ├── Models/           # Core Data 模型
│   │   ├── Entry.swift
│   │   ├── Library.swift
│   │   ├── Group.swift
│   │   ├── Attachment.swift
│   │   └── Document.swift
│   ├── Theme/
│   │   └── AppTheme.swift  # 主題系統核心
│   ├── Services/         # 業務邏輯層
│   ├── ViewModels/       # MVVM 架構
│   └── Views/            # UI 視圖
│       ├── NewContentView.swift
│       ├── Sidebar/
│       ├── Common/
│       ├── EntryList/
│       ├── EntryDetail/
│       ├── Editor/
│       └── Writer/
├── PROJECT_STATUS.md     # 專案進度（需自動更新）
└── OVEREND_Brand_Product_Design_Manual.md
```

## Core Workflow

### 標準開發流程

每次執行開發任務時，遵循以下步驟：

#### 1. 理解需求
- 確認使用者要修復的 bug 或新增的功能
- 識別涉及的檔案與模組

#### 2. 查看相關程式碼
```bash
# 使用 view 工具查看檔案
view /Users/lawliet/OVEREND/OVEREND/Views/xxx.swift
```

#### 3. 執行編輯
```bash
# 使用 str_replace 或 create_file
# 確保遵循命名規範與編碼標準
```

#### 4. 編譯檢查
```bash
cd /Users/lawliet/OVEREND
xcodebuild -scheme OVEREND build 2>&1 | grep -E "error:"
```

#### 5. 更新文件
- 更新 `PROJECT_STATUS.md`
- 輸出 Notion 開發日記格式

### 修 Bug 工作流程

```
1. view 相關檔案
2. 識別問題根源
3. str_replace 修正程式碼
4. 編譯檢查
5. 執行相關測試（如有）
6. 驗證符合規範
7. 更新文件
```

### 新增功能工作流程

```
1. 確認檔案命名與位置
2. create_file 建立新檔案
3. 檢查 Core Data 模型（如需要）
4. 驗證主題系統與中文化
5. 編譯檢查
6. 考慮是否需要新增測試
7. 更新文件
```
6. 更新文件
```

### 程式碼審查工作流程

```
1. view 目標檔案
2. 檢查命名規範
3. 驗證主題系統使用
4. 確認中文化完整性
5. 識別重複程式碼
6. 提供優化建議
```

## Coding Standards

### 1. 命名規範

**必須嚴格遵守**：

| 類型 | 規則 | 正確範例 | 錯誤範例 |
|------|------|----------|----------|
| 視圖 | PascalCase + View | `ModernEntryListView` | `entryList`, `entry_view` |
| 視圖模型 | PascalCase + ViewModel | `LibraryViewModel` | `LibraryVM`, `library_view_model` |
| 服務 | PascalCase + Service | `CitationService` | `citation`, `cite_service` |
| 檔案名 | 與類別同名 | `EntryDetailView.swift` | `entryDetail.swift` |

**新版 UI 元件**使用 `Modern` 或 `New` 前綴：
- `NewContentView` - 新版主容器
- `NewSidebarView` - 新版側邊欄
- `ModernEntryListView` - 現代化列表
- `ModernEntryDetailView` - 現代化詳情

### 2. 主題系統使用

**強制規則**：所有顏色必須來自 `AppTheme.swift`

✅ **正確**：
```swift
@EnvironmentObject var theme: AppTheme

Text("標題")
    .foregroundColor(theme.textPrimary)
    .background(theme.card)
```

❌ **錯誤**：
```swift
Text("標題")
    .foregroundColor(.green)  // 不可直接使用 Color
    .background(Color(hex: "#00D97E"))  // 不可硬編碼顏色
```

**可用的主題顏色**：
- `theme.primary` - 主色調 (#00D97E)
- `theme.textPrimary` - 主要文字
- `theme.textSecondary` - 次要文字
- `theme.card` - 卡片背景
- `theme.background` - 頁面背景

### 3. 中文化規範

**必須確保**：

✅ **正確**：
```swift
Text("全部文獻")  // 繁體中文
Button("新增書目")  // 台灣學術用語
Text("匯入成功，共 10 筆。")  // 全形標點
```

❌ **錯誤**：
```swift
Text("全部文献")  // 簡體中文
Button("新增文獻")  // 使用「文獻」而非「書目」
Text("导入成功,共10笔.")  // 簡體 + 半形標點
```

**台灣學術用語對照**：
- 使用「書目」而非「文獻」
- 使用「匯入」而非「導入」
- 使用「引用」而非「引述」
- 標點使用全形：，。「」（）

### 4. 檔案結構規範

新增檔案時必須放置於正確目錄：

| 檔案類型 | 目錄 | 範例 |
|----------|------|------|
| Core Data 模型 | `OVEREND/Models/` | `Entry.swift` |
| 視圖 | `OVEREND/Views/[子目錄]/` | `Views/EntryList/ModernEntryListView.swift` |
| 視圖模型 | `OVEREND/ViewModels/` | `LibraryViewModel.swift` |
| 服務 | `OVEREND/Services/` | `CitationService.swift` |
| 主題 | `OVEREND/Theme/` | `AppTheme.swift` |

## Quality Checks

### 每次任務完成前必須確認

- [ ] 程式碼符合命名規範（PascalCase + 後綴）
- [ ] 所有顏色使用 `AppTheme.swift` 定義
- [ ] UI 文字使用繁體中文與台灣學術用語
- [ ] 標點符號使用全形
- [ ] 檔案位置正確
- [ ] 編譯無錯誤
- [ ] 相關測試已執行並通過（如有修改核心功能）
- [ ] `PROJECT_STATUS.md` 已更新
- [ ] 開發日記格式已輸出

### 程式碼審查檢查項目

1. **命名檢查**：
   - 類別名稱符合規範
   - 變數名稱有意義
   - 無拼寫錯誤

2. **主題系統檢查**：
   - 無硬編碼顏色值
   - 正確使用 `@EnvironmentObject var theme: AppTheme`

3. **中文化檢查**：
   - 所有 UI 字串使用繁體中文
   - 使用台灣學術用語
   - 全形標點符號

4. **架構檢查**：
   - 遵循 MVVM 模式
   - 視圖與業務邏輯分離
   - 無重複程式碼

## Testing Framework

### 測試架構總覽

OVEREND 專案包含完整的測試框架：

#### 測試目錄結構
```
OVEREND/
├── OVERENDTests/              # 單元測試（12 個檔案）
│   ├── CitationServiceTests.swift       # 引用格式測試 (289 行)
│   ├── BibTeXParserTests.swift          # BibTeX 解析測試 (370 行)
│   ├── PDFMetadataExtractorTests.swift  # PDF 提取測試
│   ├── AiritiServiceTests.swift         # 華藝 DOI 測試
│   ├── AIServiceTests.swift             # AI 服務測試
│   ├── LiteratureAgentTests.swift       # 文獻 Agent 測試
│   ├── AgentTaskQueueTests.swift        # 任務佇列測試
│   ├── LearningServiceTests.swift       # 學習服務測試
│   ├── RepositoryTests.swift            # 資料存取測試
│   ├── NewFeaturesTests.swift           # 新功能測試
│   ├── CoreDataTestHelper.swift         # Core Data 測試工具
│   └── OVERENDTests.swift               # 測試範本
│
└── OVERENDUITests/            # UI 測試（4 個檔案）
    ├── EditorUITests.swift              # 編輯器 UI 測試
    ├── LibraryUITests.swift             # 文獻庫 UI 測試
    ├── OVERENDUITests.swift             # 通用 UI 測試
    └── OVERENDUITestsLaunchTests.swift  # 啟動測試
```

### 執行測試

#### 方法 1：在 Xcode 中執行
```
1. 打開 OVEREND.xcodeproj
2. 按 Cmd + U（執行所有測試）
3. 或點擊測試檔案旁的 ▶️ 按鈕（執行單一測試）
```

#### 方法 2：使用指令列執行所有測試
```bash
cd /Users/lawliet/OVEREND
xcodebuild test -scheme OVEREND -destination 'platform=macOS'
```

#### 方法 3：只執行單元測試
```bash
cd /Users/lawliet/OVEREND
xcodebuild test -scheme OVEREND -destination 'platform=macOS' -only-testing:OVERENDTests
```

#### 方法 4：執行特定測試類別
```bash
cd /Users/lawliet/OVEREND
xcodebuild test -scheme OVEREND -destination 'platform=macOS' -only-testing:OVERENDTests/CitationServiceTests
```

#### 方法 5：執行特定測試函數
```bash
cd /Users/lawliet/OVEREND
xcodebuild test -scheme OVEREND -destination 'platform=macOS' -only-testing:OVERENDTests/CitationServiceTests/testGenerateAPAForArticle
```

### 測試報告解讀

#### 成功的測試輸出範例
```
Test Suite 'CitationServiceTests' started
✅ testGenerateAPAForArticle (0.001 秒)
✅ testGenerateAPAForBook (0.001 秒)
✅ testGenerateAPAForChineseArticle (0.002 秒)

Test Suite 'CitationServiceTests' finished
總共：3 個測試
通過：3 個 ✅
失敗：0 個
時間：0.004 秒
```

#### 失敗的測試輸出範例
```
Test Suite 'BibTeXParserTests' started
✅ testParseValidBibTeX (0.001 秒)
❌ testParseInvalidBibTeX (0.002 秒)
   /Users/lawliet/OVEREND/OVERENDTests/BibTeXParserTests.swift:45
   XCTAssertThrowsError failed: did not throw an error
   
Test Suite 'BibTeXParserTests' finished
總共：2 個測試
通過：1 個 ✅
失敗：1 個 ❌
時間：0.003 秒
```

### 新增測試的標準流程

#### 1. 為新功能建立測試檔案

```swift
// 檔案位置：OVERENDTests/NewFeatureTests.swift
import XCTest
import CoreData
@testable import OVEREND

@MainActor
final class NewFeatureTests: XCTestCase {
    
    var testHelper: CoreDataTestHelper!
    var testContext: NSManagedObjectContext!
    
    override func setUp() async throws {
        await MainActor.run {
            testHelper = CoreDataTestHelper(inMemory: true)
            testContext = testHelper.viewContext
        }
    }
    
    override func tearDown() async throws {
        await MainActor.run {
            testHelper?.reset()
            testHelper = nil
            testContext = nil
        }
    }
    
    func testNewFeature() {
        // Given - 準備測試資料
        
        // When - 執行功能
        
        // Then - 驗證結果
        XCTAssertTrue(true, "測試描述")
    }
}
```

#### 2. 測試命名規範

- 測試類別：`[功能名稱]Tests`（例如：`CitationServiceTests`）
- 測試函數：`test[功能描述]`（例如：`testGenerateAPAForArticle`）
- 使用 Given-When-Then 結構註解

#### 3. 測試覆蓋率建議

**高優先級（必須測試）**：
- 核心業務邏輯（CitationService, BibTeXParser）
- 資料轉換與解析
- 錯誤處理與邊界條件

**中優先級（建議測試）**：
- 資料存取層（Repositories）
- AI 服務整合
- 檔案操作

**低優先級（選擇性測試）**：
- UI 元件互動
- 簡單 getter/setter
- 視圖邏輯

### 測試最佳實踐

#### ✅ 正確的測試寫法

```swift
// 每個測試只驗證一件事
func testAPABasicFormat() {
    let entry = createTestEntry(...)
    let result = CitationService.shared.generateAPA(entry: entry)
    XCTAssertEqual(result, "預期結果")
}

func testAPAMultipleAuthors() {
    let entry = createTestEntry(authors: ["張三", "李四"])
    let result = CitationService.shared.generateAPA(entry: entry)
    XCTAssertTrue(result.contains("張三、李四"))
}
```

#### ❌ 錯誤的測試寫法

```swift
// 一次測試太多東西
func testAPAEverything() {
    // 測試基本格式
    let entry1 = ...
    XCTAssertEqual(...)
    
    // 測試多位作者
    let entry2 = ...
    XCTAssertEqual(...)
    
    // 測試邊界條件
    let entry3 = ...
    XCTAssertEqual(...)
    // 如果第一個失敗，後面都不會執行
}
```

### 測試相關指令整合

將測試整合到開發流程：

```bash
# 修改程式碼後立即執行相關測試
cd /Users/lawliet/OVEREND
xcodebuild test -scheme OVEREND -only-testing:OVERENDTests/CitationServiceTests

# 發布前執行所有測試
xcodebuild test -scheme OVEREND -destination 'platform=macOS'

# 產生測試覆蓋率報告（在 Xcode 中查看）
xcodebuild test -scheme OVEREND -enableCodeCoverage YES
```

### 測試驅動開發（TDD）建議流程

當新增功能時，可採用 TDD 方式：

```
1. 先寫測試（紅燈階段）
   - 建立測試檔案
   - 撰寫預期行為的測試
   - 執行測試（應該失敗）

2. 實作功能（綠燈階段）
   - 撰寫最少程式碼讓測試通過
   - 執行測試確認通過

3. 重構優化（重構階段）
   - 優化程式碼結構
   - 確保測試仍然通過

4. 更新文件
   - 記錄到 PROJECT_STATUS.md
   - 生成開發日記
```

## Documentation Updates

### PROJECT_STATUS.md 更新格式

每次完成任務後更新專案狀態文件：

```markdown
## [YYYY-MM-DD] 更新

### 完成項目
- [具體功能或修復描述]

### 技術細節
- 修改檔案：`路徑/檔案名.swift`
- 變更內容：[簡要說明變更]

### 測試狀態
- [x] 編譯通過
- [x] 功能驗證
- [ ] 待測試項目（如有）
```

### Notion 開發日記格式

**務必以此格式輸出**，方便使用者複製到 Notion：

```markdown
---
📅 **日期**: YYYY-MM-DD HH:MM
🎯 **任務類型**: [修復Bug / 新增功能 / 程式碼優化 / 文件更新]
📝 **任務標題**: [簡短描述]

---

## 變更內容

**修改檔案**:
- `OVEREND/Views/xxx.swift`
- `OVEREND/Services/xxx.swift`

**具體變更**:
1. [變更項目 1]
2. [變更項目 2]

---

## 技術要點

- [關鍵決策或技術發現]
- [遇到的問題與解決方案]

---

## 品質檢查

- [x] 命名規範 ✅
- [x] 主題系統 ✅
- [x] 中文化 ✅
- [x] 編譯通過 ✅
- [x] 測試通過 ✅ (如有修改核心功能)

---

## 下一步

- [ ] [待辦事項 1]
- [ ] [待辦事項 2]

---
```

## Common Commands

### 編譯與檢查

```bash
# 導航至專案
cd /Users/lawliet/OVEREND

# 建置專案
xcodebuild -scheme OVEREND -destination 'platform=macOS' build

# 檢查編譯錯誤
xcodebuild -scheme OVEREND build 2>&1 | grep -E "error:"

# 清除建置快取
xcodebuild clean -scheme OVEREND
rm -rf ~/Library/Developer/Xcode/DerivedData
```

### 檔案操作

```bash
# 查看專案結構
ls -R /Users/lawliet/OVEREND/OVEREND/

# 搜尋 Swift 檔案
find /Users/lawliet/OVEREND/OVEREND/ -name "*.swift" -type f

# 搜尋特定內容
grep -r "AppTheme" /Users/lawliet/OVEREND/OVEREND/
```

### 測試相關指令

```bash
# 導航至專案
cd /Users/lawliet/OVEREND

# 執行所有測試
xcodebuild test -scheme OVEREND -destination 'platform=macOS'

# 只執行單元測試
xcodebuild test -scheme OVEREND -destination 'platform=macOS' -only-testing:OVERENDTests

# 只執行 UI 測試
xcodebuild test -scheme OVEREND -destination 'platform=macOS' -only-testing:OVERENDUITests

# 執行特定測試類別
xcodebuild test -scheme OVEREND -destination 'platform=macOS' -only-testing:OVERENDTests/CitationServiceTests

# 執行特定測試函數
xcodebuild test -scheme OVEREND -destination 'platform=macOS' -only-testing:OVERENDTests/CitationServiceTests/testGenerateAPAForArticle

# 產生測試覆蓋率報告
xcodebuild test -scheme OVEREND -enableCodeCoverage YES -destination 'platform=macOS'

# 查看測試檔案列表
ls -la /Users/lawliet/OVEREND/OVERENDTests/
ls -la /Users/lawliet/OVEREND/OVERENDUITests/
```

## Common Issues & Solutions

### 編譯錯誤處理

**問題**: "CitationCard redeclared"
```
原因: 不同檔案有同名 struct
解決: 使用前綴區分（如 DetailCitationCard vs ListCitationCard）
```

**問題**: "Cannot find 'theme' in scope"
```
原因: 未注入 AppTheme
解決: 確保在預覽或父視圖加入 .environmentObject(AppTheme())
```

**問題**: Core Data 驗證錯誤
```
原因: 必填欄位為 nil
解決: 檢查模型定義，確保 bibtexRaw 等欄位有預設值
```

### PDF 處理問題

**問題**: PDF 無法開啟
```
原因: App Sandbox 權限
解決: 確保使用 startAccessingSecurityScopedResource()
```

### 主題系統問題

**問題**: 深色模式顏色不正確
```
原因: 硬編碼顏色值
解決: 改用 AppTheme.swift 定義的顏色
```

## Example Usage

### 範例 1: 修復編譯錯誤

**使用者輸入**：
```
修復 ModernEntryListView 的編譯錯誤
```

**Agent 執行步驟**：
1. `view /Users/lawliet/OVEREND/OVEREND/Views/EntryList/ModernEntryListView.swift`
2. 識別錯誤：找到未定義的變數或型別錯誤
3. `str_replace` 修正程式碼
4. `bash_tool` 執行 `xcodebuild -scheme OVEREND build 2>&1 | grep -E "error:"`
5. 確認編譯通過
6. 更新 PROJECT_STATUS.md
7. 輸出 Notion 開發日記格式

### 範例 2: 新增視圖元件

**使用者輸入**：
```
新增一個書目匯出視圖
```

**Agent 執行步驟**：
1. 確認命名：`ExportBibliographyView.swift`
2. 確認位置：`OVEREND/Views/Export/`
3. `create_file` 建立檔案（包含基本 SwiftUI 結構）
4. 檢查主題系統使用：`@EnvironmentObject var theme: AppTheme`
5. 驗證中文化：Button 文字使用「匯出書目」
6. 編譯檢查
7. 更新專案文件

### 範例 3: 程式碼審查

**使用者輸入**：
```
審查 ProfessionalEditorView.swift
```

**Agent 執行步驟**：
1. `view /Users/lawliet/OVEREND/OVEREND/Views/Writer/ProfessionalEditorView.swift`
2. 檢查命名規範：✅ 符合 PascalCase + View
3. 驗證主題系統：尋找 `.foregroundColor(.green)` 等硬編碼
4. 確認中文字串：檢查是否有英文 UI 文字
5. 識別可優化區域：重複程式碼、過長方法
6. 提供改進建議清單

### 範例 4: 批次中文化檢查

**使用者輸入**：
```
檢查所有視圖的中文化
```

**Agent 執行步驟**：
1. `find /Users/lawliet/OVEREND/OVEREND/Views/ -name "*.swift"`
2. 對每個檔案執行 `grep -n "Text(" xxx.swift`
3. 檢查字串是否為繁體中文
4. 列出需要修正的檔案與行號
5. 提供修正建議

### 範例 5: 執行測試並修復失敗

**使用者輸入**：
```
執行 CitationService 的測試
```

**Agent 執行步驟**：
1. 執行測試：`xcodebuild test -scheme OVEREND -only-testing:OVERENDTests/CitationServiceTests`
2. 解讀測試結果
3. 如有失敗，查看失敗的測試函數
4. `view` 相關測試檔案與主程式
5. 識別問題並修復
6. 重新執行測試確認通過
7. 更新文件

### 範例 6: 為新功能新增測試

**使用者輸入**：
```
我新增了一個 DOI 驗證功能，幫我寫測試
```

**Agent 執行步驟**：
1. `view` DOI 驗證功能的程式碼
2. 在 `OVERENDTests/` 建立 `DOIValidatorTests.swift`
3. 撰寫測試案例：
   - 有效的 DOI 格式
   - 無效的 DOI 格式
   - 邊界條件（空值、特殊字元）
4. 執行測試確認通過
5. 更新文件並記錄測試覆蓋率

## Three-View Navigation System

OVEREND 應用有三種主要視圖模式：

| 模式 | 說明 | 入口 | 對應檔案 |
|------|------|------|----------|
| **文獻管理** | 文獻列表 + 詳情面板 | 側邊欄「全部文獻」 | `ModernEntryListView` + `ModernEntryDetailView` |
| **寫作中心** | 文稿卡片網格 | 側邊欄「寫作中心」 | `EditorListView` |
| **專業編輯** | Word 風格編輯器 | 雙擊文稿卡片 | `ProfessionalEditorView` |

視圖狀態由 `MainViewState` 管理：

```swift
enum ViewMode {
    case library      // 文獻管理
    case editorList   // 寫作中心
    case editorFull   // 專業編輯
}
```

## Best Practices

### 1. 事實檢查思考

- 僅基於實際檔案內容進行修改
- 不假設或推測程式碼結構
- 使用 `view` 工具確認後再編輯

### 2. 不主動提供程式碼

- 除非使用者明確要求查看程式碼
- 直接使用 Desktop Commander 工具編輯
- 完成後說明變更內容即可

### 3. 漸進式修改

- 一次修改一個問題
- 每次修改後執行編譯檢查
- 避免大規模重構（除非使用者要求）

### 4. 清晰的溝通

- 說明將要執行的步驟
- 編譯錯誤時提供明確的錯誤訊息
- 完成後總結變更內容

## Limitations

1. **不修改 Core Data 模型結構**：
   - 僅在使用者明確要求時修改 `.xcdatamodeld`
   - 避免破壞現有資料結構

2. **不調整 Xcode 專案設定**：
   - 不修改 Build Settings
   - 不調整 Info.plist（除非必要）

3. **不處理版本控制**：
   - 建議使用者在重大變更前 Git commit
   - 不自動執行 git 指令

4. **需要編譯驗證**：
   - 所有程式碼變更後必須編譯檢查
   - 確保不引入新的錯誤

## Reference Files

- **專案開發指南**: `/Users/lawliet/OVEREND/開發指南.md`
- **專案狀態**: `/Users/lawliet/OVEREND/PROJECT_STATUS.md`
- **品牌手冊**: `/Users/lawliet/OVEREND/OVEREND_Brand_Product_Design_Manual.md`

---

**建立日期**: 2025-01-21
**版本**: 1.0
**維護者**: 彥儒 (Lawliet)
